import unidecode
import random
from tkinter import *



def motus():
    '''
    fonction qui execute le jeu
    '''
    est_gagne = False
    tab =[]
    word_len = int(niveau()) #demande le niveau de la partie
    max_tries = nbr_essai(word_len) #donne le nombre d'essai autorisé dans la partie
    print('tu auras donc ', max_tries, 'essais pour trouver le mot caché')
    word = random_words(word_len, get_words_dict(load_word('frenchDict.txt'))) #trouve un mot aléatoire du nombre de lettre du niveau
    essais = 0
    while not est_gagne and essais < max_tries: #tant que la partie n'est pas gagné est qu'il reste des essais 
        proposition = clean_word(input('propose moi un mot du nombre de lettre du niveau:  ')).upper() 
        if len(proposition) != word_len and proposition not in get_words_dict(load_word('frenchDict.txt')):#redemande au joueur de mettre un mot ayan4t le même nombre de lettre que le mot caché
            print("Le mot doit faire", word_len, "lettres et doit être dans le dictionnaire.")
            continue
        a_try = print_clues(word, check_word(word, proposition),proposition) #test la proposition du joueur avec l'affichage du mot
        tab.append(a_try) #ajoute l'essai dans la liste des essais
        liste_mot_jouer(tab) #affiche la liste des essais
        if word == proposition: #si la propostion est le mot secret, est_gagne devient vrai.
            est_gagne = True
        essais += 1
    rejouer(est_gagne, word, essais) #lance la fonction qui demande si le joueur veut rejouer
    

############## fonction demander dans le TP ##################

def clean_word(word):
    '''
    fonction qui "clean" le mot : enlève les accents, les espaces et ponctuations et met les lettre en Majuscule.
    :params word(str)
    :return (str)
    >>> clean_word('égouter.')
    'EGOUTER'
    >>> clean_word('étandoir?')
    'ETANDOIR'
    '''
    assert isinstance(word, str), 'word est unes chaine de caractère'
    new_word = ""
    dic = [' ', '.', ';', '-', '_',':','!','?','\n']
    for letter in word:   # pour toutes les lettres du mot enleve les accents et les ponctuations
        if letter not in dic:
            new_word += letter
    return unidecode.unidecode(new_word).upper()

def load_word(filename):
    '''
    Ouvre le fichier 'frenchDict' est uniformise les mots
    '''
    assert isinstance(filename, str), 'le nom du fichier est une chaine de caractère'
    f = open(filename, "r", encoding="utf8")
    words = f.readlines()
    tab_word = []
    for word in words:
        words_clean = clean_word(word)
        tab_word.append(words_clean)
    return tab_word


def get_words_dict(tab_words):
    '''
    Fonction qui renvoie un dictionnaire contenant tous ces mots triés par longueur dans un dictionnaire
    :params liste_mot (list)
    :return (dic)
    >>> get_words_dict(["camp", "six", "mange","genre"])
    {4: ['camp'], 3: ['six'], 5: ['mange', 'genre']}
    '''
    assert isinstance(tab_words, list), "tab_words est un tableau"
    dic = {}
    for word in tab_words:    #pour tout les mot du tableau de mot, si il n'y a pas encore de mot du même nombre de lettre ajoute une clé du nombre de lettre et le mot en valeur et sinon ajout le mot en valeur dans la clé correspondante
        if len(word) in dic:
            dic[len(word)].append(word)
        else:
            dic[len(word)] = [word]
    return dic

def random_words(n, dic):
    '''
    Fonction qui choisit un mot aléatoire dans le nombre N sélectioner
    :params n (int)
            dic (dic)
    :return (str)
    '''
    return random.choice(dic[n])    #return un mot aléatoire parmi le dictionnaire
def check_word(secret_word, word_try):
    '''
    Fonction qui compare le mot proposé pour savoir quels sont les lettres correspondantes
    :params secret_word (str)
            word_try (str)
    :return list
    >>> check_word('TRACTER', 'TIRADES')
    [1, -1, 0, 0, -1, 1, -1]
    '''
    assert isinstance(secret_word, str), "secret_word est une chaine"
    assert isinstance(word_try, str), "secret_word est une chaine"
    tab = []
    dic = {}
    for letter in secret_word:    #fait un dictionnaire du mot et du nombre de lettre présent dans le mot
        if letter in dic:
            dic[letter] += 1
        else:
            dic[letter] = 1
    for i in range(len(secret_word)):       #pour toutes les lettres du mot regarde si la lettre est au bonne endroit 
        if secret_word[i] == word_try[i]:
            tab.append(1)
            dic[word_try[i]] -= 1
        else:
            tab.append(-1)
    for i in range(len(secret_word)):     #pour toutes les lettres au mauvaise endroit regarde si elle est présente dans le mot ou non
        if word_try[i] in secret_word and secret_word[i] != word_try[i] and dic[word_try[i]] > 0:
            tab[i] = 0
            dic[word_try[i]] -= 1
    return tab

def print_clues(word, tab_int, word_try):
    '''
    Fonction qui met en forme le tableau de la fonction check_word(secret_word, word_try) en affichant le mot que l'on cherche et les lettre validé ou présente
    :params word (str)
            tab_int (list)
    :retrun str
    >>> print_clues('CAMPING', [1, 1, -1, 0, 0, -1, -1], 'CABINET')
    'CA_(I)(N)__'
    '''
    assert isinstance(word, str), "word est une chaine"
    assert isinstance(tab_int, list), "tab_int est une liste de nombre"
    result = ""
    for i in range(len(word)):
        if tab_int[i] == -1:
            result += "_"
        elif tab_int[i] == 0:
            result += "(" + word_try[i] + ")"
        else:
            result += word[i]
    return result



############### fonction annexe ##################

def niveau():
    '''
    Fonction qui demande le niveau de la partie (celui_ci doit être compris entre 3 et 25)
    '''
    print("Bienvenue dans le motus développer par Antoine Normand.\nJ'imagine que tu connais les règles, donc avec quel niveau de difficulté veux-tu jouer ?")
    niveau = 0
    while int(niveau) < 3 or int(niveau) > 25:
        niveau = input("le niveau correspond au nombre de lettre à trouver, tu peux choisir entre 3 et 25:  ")
    return niveau

def nbr_essai(niveau):
    '''
    fonction qui donne le nombre d'essaipour trouver le mot (5 minimums et +2 à 10, +2 à 15 etc...)
    :params niveau (int)
    :return (int)
    '''
    assert isinstance(niveau, int), 'niveau est un entier'
    essai = 5
    if niveau >= 10: 
        essai = 7 
    if niveau >= 15:
        essai = 9
    if niveau >= 20 :
        essai = 10
    
    return essai

def liste_mot_jouer(tab):
    """
    affiche la liste des essais ligne par ligne présent dans tab
    :param tab (list)
    """
    assert isinstance(tab, list), 'tab est un tableau'
    for elt in tab:
        print(elt)

def rejouer(est_gagne, word, essais):
    '''
    Demande au joueur si celui veut rejouer ou non et si il a gagné lui affiche en cobien de coups 
    :params est_gagne (bool)
            word (str)
            essais (int)
    '''
    assert isinstance(est_gagne,bool), 'est_gagne est un boolean'
    assert isinstance(word,str), 'word est une chaine de caractère'
    assert isinstance(essais,int), 'essais est un nombre entier positif'
    if est_gagne:
        rejouer = input('bien jouer vous avez gagné en '+ str(essais) + ' coup(s) voulez-vous rejouer ? (oui/non) ')
        if rejouer == "oui":
            motus()
        else: 
            print('a bientôt')
    if not est_gagne:
        rejouer_ = input('dommage le mot était ' + word + ' voulez-vous rejouer ? (oui/non) ')
        if rejouer_ == "oui":
            motus()
        else: print('a bientôt')



############### doctest ##########################
if __name__ == "__main__":
    import doctest
    doctest.testmod()
    motus()

